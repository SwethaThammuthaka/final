package com.customercare.dto;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.customercare.model.Incident;


@SuppressWarnings("serial")
@Entity(name="Support_Engineer")
public class SupEngTable implements Serializable {
	@Id
	@GeneratedValue
	private int eng_id;
	
	private String available_status;
	
	private String eng_name;
	
	private int tickets_count;
	
	private int rating;
	
	private Date new_date;
 private List<Incident> assigned_Tickets;
	public int getEng_id() {
		return eng_id;
	}

	public void setEng_id(int eng_id) {
		this.eng_id = eng_id;
	}

	public String getAvailable_status() {
		return available_status;
	}

	public void setAvailable_status(String available_status) {
		this.available_status = available_status;
	}

	public String getEng_name() {
		return eng_name;
	}

	public void setEng_name(String eng_name) {
		this.eng_name = eng_name;
	}

	public int getTickets_count() {
		return tickets_count;
	}

	public void setTickets_count(int tickets_count) {
		this.tickets_count = tickets_count;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Date getNew_date() {
		return new_date;
	}

	public void setNew_date(Date new_date) {
		this.new_date = new_date;
	}

	public SupEngTable() {
		super();
	}

	public SupEngTable(int eng_id, String available_status, String eng_name, int tickets_count, int rating,
			Date new_date) {
		super();
		this.eng_id = eng_id;
		this.available_status = available_status;
		this.eng_name = eng_name;
		this.tickets_count = tickets_count;
		this.rating = rating;
		this.new_date = new_date;
	}

	@Override
	public String toString() {
		return "SupEngTable [eng_id=" + eng_id + ", available_status=" + available_status + ", eng_name=" + eng_name
				+ ", tickets_count=" + tickets_count + ", rating=" + rating + ", new_date=" + new_date + "]";
	}
	
	
	
}
