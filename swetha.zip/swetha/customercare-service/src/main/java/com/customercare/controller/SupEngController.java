package com.customercare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.customercare.dto.SupEngTable;
import com.customercare.service.SupEngService;


@RestController
public class SupEngController {
	
	@Autowired
	SupEngService supengService;
	
	@GetMapping("/getAvailableSupEngs")
	public List<SupEngTable> getAllAvailableSupEngs() {
		
		return supengService.getAllAvailableSupEngs();
	}
	
	@GetMapping("/addsuppEng/{incidentId}/{supengId}")
	public String addSupportEngineer( @PathVariable("incidentId") int  incidentId, @PathVariable("supengId") int supengId) {
		
		return supengService.addEngtoTicket(supengId, incidentId);
		
	}
	
	@PostMapping("/addEnginner")
	public String addEnginner(@RequestBody SupEngTable supEngTable) {		
		int status = supengService.addEnginnertoSystem(supEngTable);		
		if(status >0)
		return "userAdded";
		else    
			return "failed";
	}
	

}
