package com.customercare.repository;

import java.sql.Types;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.customercare.dto.IncidentMapping;
import com.customercare.dto.SupEngTable;

@Repository
public class ServiceDetailsRepository {
	
	 @Autowired
	 JdbcTemplate jdbcTemplate;
	 
	
	   String selectQuery = "select * from support_engineer where available_status = 'open'";
	   

		
		public List<SupEngTable> loadallAvailableSupEngs() {
			
			List<SupEngTable> availableSupEngs = jdbcTemplate.query(selectQuery, new BeanPropertyRowMapper<SupEngTable>(SupEngTable.class));
			
			return availableSupEngs;
		}
		
		public SupEngTable getsupportEnginner(int suppengId) {
			
			   String supEngById = "select * from support_engineer where eng_Id = "+suppengId;
			   
			   SupEngTable suppEngDetails = jdbcTemplate.queryForObject(supEngById,new BeanPropertyRowMapper<SupEngTable>(SupEngTable.class));
		
			   return suppEngDetails;
		}
		
		 public IncidentMapping loadIncidentsById(int incidentId) {
				
			   
			    String selectQuery = "select * from incident where incident_id= "+incidentId;

			    IncidentMapping openIncidents = jdbcTemplate.queryForObject(selectQuery, new BeanPropertyRowMapper<IncidentMapping>(IncidentMapping.class));
				
				return openIncidents;
			}
		 public void updateEngineerstatus(SupEngTable supEngTable, IncidentMapping incMapping) {
			
			 String updatequery ="update support_engineer set tickets_count = ? , new_date = ? where eng_id = ?";
			 jdbcTemplate.update(updatequery,supEngTable.getTickets_count(),new Date(),supEngTable.getEng_id());
			 
			 
			 String updateIncident = "update incident set ticket_status = ?  where incident_id = ?";
			 jdbcTemplate.update(updateIncident,incMapping.getTicket_status(),incMapping.getIncident_id());
			 
		 }
		 
		 public int addEnginnerTOSystem(SupEngTable supEngTable) {
			 String sql = "insert into support_engineer(eng_id, available_status, eng_name, tickets_count, rating, new_date) values ("
						+ "?,?,?,?,?,?)";
			 
			 
			 Object[] params = new Object[] {supEngTable.getEng_id(),supEngTable.getAvailable_status(), supEngTable.getEng_name(),
					                        supEngTable.getTickets_count(), supEngTable.getRating(), new Date()};

            int[] types = new int[] {Types.INTEGER, Types.VARCHAR,Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.DATE};

            int  recordStatus = jdbcTemplate.update(sql, params, types);
            
            return recordStatus;
		 }
}
