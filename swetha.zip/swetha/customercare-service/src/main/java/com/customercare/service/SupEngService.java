package com.customercare.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customercare.dto.IncidentMapping;
import com.customercare.dto.SupEngTable;
import com.customercare.repository.ServiceDetailsRepository;


@Service
public class SupEngService {
	@Autowired
	ServiceDetailsRepository supengRepository;
	
	public List<SupEngTable> getAllAvailableSupEngs() {
	      List<SupEngTable> availableSupEngs = supengRepository.loadallAvailableSupEngs();
		
		return availableSupEngs;
	}
	
	public String addEngtoTicket(int engId, int incId) {
		IncidentMapping incidentStatus = supengRepository.loadIncidentsById(incId);
		
		SupEngTable supEngStatus = supengRepository.getsupportEnginner(engId);
		
		
		if(incidentStatus.getTicket_status().equals("closed") ){
			
			System.out.println("If 1 "+incidentStatus);
			return "ticket already closed....";
		}
		else if(incidentStatus.getTicket_status().equals("Assigned") ) {
			System.out.println("If 1 "+incidentStatus);
			return "ticket already Assigned ....";
		}
		
		Date present = new Date();
		
		System.out.println("Present:"+present);
		
		System.out.println("DB Value ::"+supEngStatus.getNew_date());
		
		System.out.println("New Logic Checking::");

		System.out.println("Validation:"+present.compareTo(supEngStatus.getNew_date()));
		if(present.compareTo(supEngStatus.getNew_date())<0) {
			supEngStatus.setTickets_count(0);
		}
		
		if(supEngStatus.getTickets_count() > 2) {
			System.out.println("If 2 "+supEngStatus);

			return "mentioned engineer is not available for the service";			
		}
		
		incidentStatus.setTicket_status("Assigned");
		incidentStatus.setAssigend_To(supEngStatus.getEng_id());
		
		supEngStatus.setTickets_count(supEngStatus.getTickets_count()+1);
		
		supengRepository.updateEngineerstatus(supEngStatus, incidentStatus);
		
		return "Support Enginner added successfully";
	}
	
	public int addEnginnertoSystem(SupEngTable supEngTable) {
		
		int status = supengRepository.addEnginnerTOSystem(supEngTable);
		return status;
	}
	

}
