/*
 * package com.customercare.model;
 * 
 * 
 * import javax.persistence.Entity; import javax.persistence.Id;
 * 
 * @Entity public class SupportEngineer {
 * 
 * @Id private int engId; private String engName; private int ticketsCount;
 * private boolean availableStatus; public int getEngId() { return engId; }
 * public void setEngId(int engId) { this.engId = engId; } public String
 * getEngName() { return engName; } public void setEngName(String engName) {
 * this.engName = engName; } public int getTicketsCount() { return ticketsCount;
 * } public void setTicketsCount(int ticketsCount) { this.ticketsCount =
 * ticketsCount; } public boolean isAvailableStatus() { return availableStatus;
 * } public void setAvailableStatus(boolean availableStatus) {
 * this.availableStatus = availableStatus; }
 * 
 * 
 * 
 * }
 */