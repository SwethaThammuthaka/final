package com.customercare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomercareApplication {
	public static void main(String[] args) {
		SpringApplication.run(CustomercareApplication.class, args);
	}
}
