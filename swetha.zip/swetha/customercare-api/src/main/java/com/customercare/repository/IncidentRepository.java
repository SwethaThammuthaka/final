package com.customercare.repository;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.customercare.model.Incident;



@Repository
public class IncidentRepository {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	public static  Map<Integer , Incident> noOfIncidents = new HashMap<Integer, Incident>();

	public int addIncident(Incident incident) {
		//noOfIncidents.put((int) incident.getIncidentId(), incident);
		String sql = "insert into incident(incident_id, incident_category, request_description, requester_name, ticket_status) values ("
				+ "?,?,?,?,?)";
		
		Object[] params = new Object[] {incident.getIncidentId(), incident.getIncidentCategory(),
				                  incident.getRequestDescription(), incident.getRequesterName(), incident.getTicketStatus()};
		
		int[] types = new int[] {Types.INTEGER, Types.VARCHAR,Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
		
		int recordStatus = jdbcTemplate.update(sql, params, types);
		
		
		//System.out.println("Total incidents:"+noOfIncidents.size());
		
	return recordStatus;
	}
	
	public int updateIncident(Incident incident) {
		//noOfIncidents.put((int) incident.getIncidentId(), incident);
		
		//TODO
		//String sql = "insert into incident(incident_id, incident_category, request_description, requester_name, ticket_status) values ("
		//		+ "?,?,?,?,?)";
		
		String sqlUpdate = "update incident set incident_category = ?, request_description = ? , requester_name = ? , ticket_status = ?  where incident_id = ?";
		
		Object[] params = new Object[] {incident.getIncidentCategory(),
				                  incident.getRequestDescription(), incident.getRequesterName(), incident.getTicketStatus(), incident.getIncidentId()};
		
		int[] types = new int[] { Types.VARCHAR,Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.INTEGER};
		
		int recordStatus = jdbcTemplate.update(sqlUpdate, params, types);
		
		
		//System.out.println("Total incidents:"+noOfIncidents.size());
		
	return recordStatus;
	}
	
	public Incident trackIncident(Integer incidentId) {
		String sql = "select * from incident where incident_id = "+incidentId;
		
		Incident incident = jdbcTemplate.queryForObject(sql,new BeanPropertyRowMapper<Incident>(Incident.class));
		
		if(incident == null)
		return null;
		else 
			return incident;
	}
	
}