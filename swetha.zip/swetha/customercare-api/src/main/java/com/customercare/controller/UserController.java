package com.customercare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.customercare.model.Incident;
import com.customercare.repository.IncidentRepository;

@RestController
public class UserController {
	
	@Autowired
	IncidentRepository incidentRepository;
	
	@GetMapping("/healthCheck")
	public String getHealthStatus() {
		
		return "Success";
	}
	
	@PostMapping("/addIncident")
	public String addIncident(@RequestBody Incident incident) {		
		int status = incidentRepository.addIncident(incident);		
		if(status >0)
		return "userAdded";
		else 
			return "failed";
	}
	
	@PostMapping("/updateIncident")
	public String updateIncident(@RequestBody Incident incident) {		
		int status = incidentRepository.updateIncident(incident);		
		if(status >0)
		return "userUpdated";
		else 
			return "failed";
	}
	
    @GetMapping("/trackIncident/{incidentId}")
	public Incident trackIncident(@PathVariable("incidentId") int incidentId) {		
    	Incident status = incidentRepository.trackIncident(incidentId);		
		return status;
	}
	
	

}
