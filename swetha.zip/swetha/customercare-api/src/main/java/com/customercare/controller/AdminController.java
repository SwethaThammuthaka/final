package com.customercare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.customercare.model.Incident;
import com.customercare.repository.IncidentRepository;
import com.customercare.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	IncidentRepository incidentRepository;
	
	@Autowired
	AdminService adminService;
	
	@GetMapping("/getIncidents")
	public List<Incident> getAllIncidents() {
		
		return adminService.getAllOpenIncidents();
	}
	
	@GetMapping("/getIncidents/{Id}")
	public Incident getAllIncidentByid(@PathVariable("Id") int id) {
		
		return adminService.getIncidentById(id);
	}
	
	

}
