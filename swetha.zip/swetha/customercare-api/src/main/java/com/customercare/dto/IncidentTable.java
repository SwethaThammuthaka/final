/*
 * package com.customercare.dto;
 * 
 * public class IncidentTable {
 * 
 * public int getIncident_id() { return incident_id; }
 * 
 * 
 * public void setIncident_id(int incident_id) { this.incident_id = incident_id;
 * }
 * 
 * 
 * public String getIncident_category() { return incident_category; }
 * 
 * 
 * public void setIncident_category(String incident_category) {
 * this.incident_category = incident_category; }
 * 
 * 
 * public String getRequest_description() { return request_description; }
 * 
 * 
 * public void setRequest_description(String request_description) {
 * this.request_description = request_description; }
 * 
 * 
 * public String getRequester_name() { return requester_name; }
 * 
 * 
 * public void setRequester_name(String requester_name) { this.requester_name =
 * requester_name; }
 * 
 * 
 * public String getTicket_status() { return ticket_status; }
 * 
 * 
 * public void setTicket_status(String ticket_status) { this.ticket_status =
 * ticket_status; }
 * 
 * 
 * private int incident_id;
 * 
 * private String incident_category;
 * 
 * private String request_description;
 * 
 * private String requester_name;
 * 
 * private String ticket_status;
 * 
 * 
 * 
 * 
 * public IncidentTable() { }
 * 
 * 
 * public IncidentTable(int incident_id, String incident_category, String
 * request_description, String requester_name, String ticket_status) { super();
 * this.incident_id = incident_id; this.incident_category = incident_category;
 * this.request_description = request_description; this.requester_name =
 * requester_name; this.ticket_status = ticket_status; } }
 */