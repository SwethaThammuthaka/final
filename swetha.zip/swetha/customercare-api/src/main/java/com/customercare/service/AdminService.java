package com.customercare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customercare.model.Incident;
import com.customercare.repository.AdminRepository;

@Service
public class AdminService {
		
	@Autowired
	AdminRepository adminRepository;

	public List<Incident> getAllOpenIncidents() {
	      List<Incident> openIncidents = adminRepository.loadallOpenIncidents();
		
		return openIncidents;
	}
	
	public Incident getIncidentById(int incidentId) {
	      Incident  openIncidents = adminRepository.loadIncidentsById(incidentId);
		
		return openIncidents;
	}
}
