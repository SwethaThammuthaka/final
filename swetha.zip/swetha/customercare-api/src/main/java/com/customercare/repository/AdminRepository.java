package com.customercare.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.customercare.model.Incident;

@Repository
public class AdminRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
    String selectQuery = "select * from incident where ticket_status= 'open'";

	
	public List<Incident> loadallOpenIncidents() {
		
		List<Incident> openIncidents = jdbcTemplate.query(selectQuery, new BeanPropertyRowMapper<Incident>(Incident.class));
		
		return openIncidents;
	}
	
   public Incident loadIncidentsById(int incidentId) {
		
	   
	    String selectQuery = "select * from incident where incident_id= "+incidentId;

		Incident openIncidents = jdbcTemplate.queryForObject(selectQuery, new BeanPropertyRowMapper<Incident>(Incident.class));
		
		return openIncidents;
	}
}
